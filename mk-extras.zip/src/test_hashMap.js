const HashMap = require("./hashMap");
const assert = require("assert");

const Map1 = new HashMap();

assert(Map1.size() == 0, "size should be 0 after initialization");
Map1.set("hello", "world");
assert(Map1.get("hello") === "world", "hello should equal world");

const something = { hello: "world", frogs: "arenice" };
Map1.set("something", something);

const maybeSomething = Map1.get("something");

assert(
  something.hello === "world" && something.frogs === "arenice",
  "key/value retrieval mismatch"
);
console.log("all tests passed!");
