module.exports = function() {
  return {
    insert: function(id, item, priority) {
      //
    },
    pop: function() {
      //
    },
    setPriority: function(id, newPriority) {
      //
    },
    getPriority: function(id) {
      //
    },
    size: function() {
      //
    }
  };
};
