module.exports.sillyHashFunc1 = function(data, keyMask) {
  let v = 0;
  for (let i = 0; i < data.length; i++) {
    v += data.charCodeAt(i);
  }
  return v & keyMask;
};
module.exports = function() {
  const HASH_FUNC_WORDLENGTH = 0xffff;
  const items = new Array(HASH_FUNC_WORDLENGTH);
  let BUCKET_COUNT = items.length;
  let TOTAL_ITEMS_STORED = 0;

  return {
    set: function(key, value) {
      TOTAL_ITEMS_STORED += 1;
    },
    get: function(key) {
      //
      //if (key === "hello") return "world";
      //if (key === "something") return { hello: "world", frogs: "arenice" };
    },
    remove: function(key) {
      TOTAL_ITEMS_STORED -= 1;
      // actually remove the item
    },
    size: function() {
      return TOTAL_ITEMS_STORED;
    }
  };
};
