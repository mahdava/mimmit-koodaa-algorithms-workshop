# Elementary Data Structures

## Priority queue

The priority queue is an modified FIFO (first in-first out) data structure where elements have a specific priority. Elements with lower (numerical) priorities are emitted before elements with higher (numerical) priorities. Priorities of elements can also be changed after insertion.

For simplicity, items are identified here by a key-value pair of `(id, item)`.

### Methods

`.insert(id, item, priority)`

Inserts the `item` with priority `priority` into the queue.

`.pop()`

Removes and returns the item with the highest (lowest numerical) priority from the queue.

`.setPriority(id, newPriority)`

Set the priority of the item identified by `id` to `newPriority`.

`.getPriority(id)`

Return the priority of the item identified by `id`.

`.size()`

Return the amount of items in the queue.

### Implementation

A simple, but computationally inefficient implementation, could use a simple list of key-value-priority tripplets. Sorting the list by priority after each `insert` and `setPriority` operation would be enough to guarantee that the item with the highest priority (lowest numerical) will be returned when performing the `.pop` operation.

A computationally efficient implementation could be implemented using a binary heap.

### Considerations

### Task

Implement a priority queue data structure in the `src/priorityQueue.js` file.

## Hash Map

The Hash Map associates values with keys.

### Methods

`.set(key, value)`

Stores the value `value` and makes it accessible by passing `key` to the `get` function.

`.get(key)`

Retrieves the value associated with `key`.

`.size()`

Returns the amount of items in the HashMap.

### Implementation

A core feature of the Hash Map is the function used to generate hashes from the keys given. The hash function takes the key (for simplicity's sake, a string) and returns an integer of some specific bit-length.

Values, along with keys, are stored in a list. The list is stored in an internal array, indexed by the hash value of the key.

Values are retrieved from the hash map by taking the hash of the search-key and using it to retrieve the list. Iterate through the list, taking out the key and value stored in the list. Return the value where the stored key matches the search-key.

It can be beneficial to keep track of the total amount of keys/values stored, as well as the amount of lists used.

### Considerations

The choice of hash function has a large impact on the performance of the hash map. Given a hash function that always returns `1` as its value we'd end up storing all values in the same list, and value retrieval always be a linear search. In an optimal scenario the lists used should be as short as possible, to faciliate rapid iteration through them when retrieving values. This can be achieved with a hash function that generates as diverse hash values as possible, spreading the storage locations of the lists as evenly as possible over the internal array.

### Task

Implement a HashMap in `src/hashMap.js`. You can use the command `node src/test_hashMap.js` to test your code. On codesandbox you can run this script easily:

![image showing how to run the script on codesandbox](/thm.png)
